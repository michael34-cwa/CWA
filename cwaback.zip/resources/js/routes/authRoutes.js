// import modular routes 
import webRoutes from "../modules/admin/web/routes"
import authRoutes from "../modules/auth/routes" 
export default [...authRoutes]
