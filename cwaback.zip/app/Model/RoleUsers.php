<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class RoleUsers extends Model
{
     protected $table = 'role_users'; 
}
