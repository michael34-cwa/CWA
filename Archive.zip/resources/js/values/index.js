const APP_TITLE = 'Your Blog Name'

export {
    APP_TITLE,
}