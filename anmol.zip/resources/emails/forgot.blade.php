@component('mail::message')
 <?php  print_r($content); ?>
 {{ config('app.name') }}
@endcomponent