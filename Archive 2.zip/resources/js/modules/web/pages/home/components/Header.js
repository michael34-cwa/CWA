import React from "react"

const displayName = "HomePageHeader"

function Header() {
  return ''
}
Header.displayName = displayName

export default Header
